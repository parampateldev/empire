# Empire

A live room companion for the social guessing game Empire. Players join from their phones, privately submit a secret identity, see the shuffled list once, and then play aloud while the host tracks empires.

## Features
- Six-character rooms and clean share links
- Private identity submission
- Synchronized timed reveal (30 seconds by default)
- Facilitator board for whole-empire captures
- Mobile-first lobby, QR code, and rematch-ready state model
- Firebase Anonymous Auth and Realtime Database
- GitHub Pages deep-link fallback

## Local development
```bash
npm install
cp .env.example .env.local
npm run dev
npm test
```
Without Firebase variables, the app opens in preview mode so the full host flow can be tested locally.

## Firebase
Create a Firebase web app, enable Anonymous Authentication and Realtime Database, then add the web config to `.env.local`. Deploy the rules in `database.rules.json` before using a production database.

## Deployment
`npm run build` produces `dist/`. GitHub Pages should publish that artifact at `/empire/`. The included `404.html` forwards direct room paths such as `/empire/AB234C` back into the app.
